varying vec2 v_uv;

void main()
{
	gl_FragColor = ...;
}
